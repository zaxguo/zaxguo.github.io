/* lwg: OPTEE-OS specific headers */
#include <types_ext.h>
#include <inttypes.h>
#include <trace.h>
#include <kernel/interrupt.h>
#include <kernel/misc.h>
/* lwg: for mapping IO registers, etc  */
#include <mm/core_memprot.h>
#include <mm/core_mmu.h>
#include <io.h>
#include <kernel/tee_time.h>

#define CHECK_DIVERGENCE() \
	if (val != expected) { \
		DMSG("%d:not as expected (val = %08x, expected = %08x)...divergence!\n", __LINE__, val, expected); \
	}\

/* lwg: The MMC driverlet -- interacation tempaltes in headers */
#include "mmc/wr_8.h"
#include "mmc/rd_8.h"
#include "mmc/replay_cb.h"
#include "mmc/block.h"
/* lwg: include SQLite test scripts */
#include "sqlite/select3.h"
#include "sqlite/insert3.h"
#include "sqlite/selectG.h"
#include "sqlite/delete.h"
#include "sqlite/io.h"
#include "sqlite/indexedby.h"
#define NUM_TESTS 6

/* lwg: replay control block, for bookkeeping device register virt addr */
struct replay_cb *replay_cb;

/* lwg: select different templates based on size of block io (bio) */
static void _bio(int rw, int sec, int cnt) {
	switch (cnt) {
	case 1:
	case 8:
		if (rw == READ) {
			rd_8(sec, replay_cb->dma_base, replay_cb->sdhost_base);
		} else {
			wr_8(sec, replay_cb->dma_base, replay_cb->sdhost_base);
		}
		break;
	case 32:
		if (rw == READ) {
			rd_32(sec, replay_cb->dma_base, replay_cb->sdhost_base);
		} else {
			wr_32(sec, replay_cb->dma_base, replay_cb->sdhost_base);
		}
		break;
	case 256:
		if (rw == READ) {
			rd_256(sec, replay_cb->dma_base, replay_cb->sdhost_base);
		} else {
			wr_256(sec, replay_cb->dma_base, replay_cb->sdhost_base);
		}
		break;
	default:
		EMSG("Unrecorded bio size!!!!! Abort!\n");
		while(1);
		break;
	}
}


/* lwg: map the physical addresses of IO registers */
void map_io_registers() {
#define DMA_BASE		0x3f007000
#define DMA_SIZE		(15 << 8)
#define SDHOST_BASE		0x3f202000
#define SDHOST_REG_SIZE 0x100
	/* an example for registering sdhost (MMC)
	 * more at (optee_os/core/arch/arm/plat-rpi3/main.c) */
	register_phys_mem_pgdir(MEM_AREA_IO_NSEC,
			SDHOST_BASE, SDHOST_REG_SIZE);
	register_phys_mem_pgdir(MEM_AREA_IO_NSEC,
			DMA_BASE, DMA_SIZE);
}

/* lwg: control block initialization, update device reigster virtual addresses */
void init_replay_cb(struct replay_cb *r_cb) {
	struct replay_cb *cb = malloc(sizeof(struct replay_cb));
	/* to virtual address */
	cb->dma_base = phys_to_virt_io(DMA_BASE);
	/* reserved 8th channel */
	cb->dma_base += (8 << 8);
	cb->sdhost_base  = phys_to_virt_io(SDHOST_BASE);
	r_cb = cb;
	EMSG("mmc replay control block init done!\n");
}

/* lwg: simple strategy to issue the actual bio */
void bio(int rw, int sec, int cnt) {
	printk("%s, %d, %d\n", (rw == READ) ? "READ" : "WRITE", sec, cnt);
	reset_sdhost(replay_cb->sdhost_base);
	/* transform the block ID to be 3-word aligned */
	if (sec & ((1 << 3) - 1)) {
		int old_sec = sec;
		sec = (sec >> 3) << 3;
		printk("adjust...%d => %d\n", old_sec, sec);
	}
	/* directly match */
	if (cnt == 1 || cnt == 8 || cnt == 32 || cnt == 256) {
		_bio(rw, sec, cnt);
		return;
	}
	/* greater than rw 100 sectors all go to 256
	 * Check: we dont have over 256 sector access */
	if (cnt > 100) {
		_bio(rw, sec, 256);
	/* fit using 32 */
	} else if (cnt > 8 && cnt < 100) {
		/* how many 32-sector read we need? */
		int need = (cnt - 1)/32 + 1;
		int i;
		for (i = 0; i < need; i++) {
			_bio(rw, sec + i * 32, 32);
		}
	} else if (cnt < 8) {
		_bio(rw, sec, 8);
	}
	return;
}

/* lwg: benchmark entry for using MMC driverlet */
void replay_entry(struct replay_cb *cb) {
	void *sdhost = cb->sdhost_base;
	void *dma	 = cb->dma_base;
	int i = 0;
	int ms_diff;
	TEE_Time start, end;
	replay_cb = cb;
	/* sqlite benchmark */
	void (*funcs[NUM_TESTS])(void) = {select3, selectG, insert3, delete, io, indexedby};
	for (int i = 0; i < NUM_TESTS; i++) {
		tee_time_get_sys_time(&start);
		(*funcs[i])();
		tee_time_get_sys_time(&end);
		ms_diff = (end.seconds - start.seconds)*1000 + (end.millis - start.millis);
		EMSG("replaying: %d KB, time = %d ms, tput = %d KB/s...\n",
			i * 4, ms_diff, (i*4)*1000/ms_diff);
	}
	/* lwg: micro benchmarks, for reference */
	tee_time_get_sys_time(&start);
	for (; i < 1; i++) {
		rd_256(0, dma, sdhost);
		/*wr_8(0, dma, sdhost);*/
		/*rd_8(0, dma, sdhost);*/
	}
	tee_time_get_sys_time(&end);
	EMSG("replaying: %d KB, time = %d ms, tput = %d KB/s...\n",
		i * 4, ms_diff, (i*4)*1000/ms_diff);
}

/* lwg: a psuedo main function, presenting an overall flow of the replay process */
int main() {
	/* step 1: configure the */
	map_io_registers();

	/* step 2: initialize replay control block (CB) which contains virtual address of IO registers */
	init_replay_cb(replay_cb);

	/* step 3: replay entry, directly invoke parameterized interaction templates */
	replay_entry(replay_cb);
}

